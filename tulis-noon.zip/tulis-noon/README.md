# Tulis Noon — تُلِسْ نُونْ

Aplikasi belajar bahasa Arab untuk pasar Indonesia. Bukan menghafal, tapi membiasakan.

## Target User
- 🕋 Jamaah umrah & wisatawan ke negara Arab
- 💼 Profesional yang butuh bahasa Arab
- 🎓 Pelajar beasiswa Timur Tengah

## Fitur MVP (Fase 1)
- ✅ Onboarding personal 5 langkah (minat, gaya belajar, aksen, komitmen)
- ✅ 3 jalur belajar (Umrah aktif, Profesi & Beasiswa coming soon)
- ✅ 4 mode game: Tebak Gambar, Quiz Video, AI Roleplay, Cerita Interaktif
- ✅ Tantangan harian + share WhatsApp
- ✅ Marketplace Guru (Kelas Grup & Privat 1-on-1)
- ✅ Premium flow dengan motivation questions
- ✅ Speech recognition & text-to-speech bahasa Arab (native browser)

## Tech Stack
- Next.js 14 (App Router)
- React 18
- Tailwind CSS
- Lucide React (icons)
- Supabase (database, akan dipakai di sesi 3)
- Claude API (AI features, akan dipakai di sesi 4)

## Deploy
Aplikasi ini di-host di Vercel. Setiap push ke branch `main` otomatis re-deploy.

Lihat **DEPLOYMENT.md** untuk panduan deploy step-by-step.

## Environment Variables
Set di Vercel Dashboard, JANGAN commit ke GitHub:
- `ANTHROPIC_API_KEY` - API key dari console.anthropic.com
- `NEXT_PUBLIC_SUPABASE_URL` - URL project Supabase
- `NEXT_PUBLIC_SUPABASE_ANON_KEY` - Anon key Supabase
